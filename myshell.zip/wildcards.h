#ifndef MYSHELL_WILDCARDS_H
#define MYSHELL_WILDCARDS_H

#include <string>
#include <vector>

bool testWildCard(std::string str, std::string wildCard);
bool isWildCard(std::string part);
std::string clearEscapeCharacters(std::string part);
std::vector<std::string> expandWildCard (const std::string partToParse);

#endif //MYSHELL_WILDCARDS_H
