#include <iostream>
#include <unordered_map>
#include <sstream>
#include <string>
#include <vector>

#include <unistd.h>
#include <sys/wait.h>

#include <boost/filesystem.hpp>
#include <readline/readline.h>
#include <readline/history.h>

#include "wildcards.h"

char** convertToCArgs(const std::vector<std::string>& variables) {
    char** result = new char*[variables.size() + 1];

    for (size_t i = 0; i < variables.size(); ++i) {
        result[i] = new char[variables[i].length() + 1];
        for (size_t c = 0; c < variables[i].length(); ++c) {
            result[i][c] = variables[i][c];
        }
        result[i][variables[i].length()] = '\0';
    }
    result[variables.size()] = nullptr;

    return result;
}

char** convertToCVariables(const std::unordered_map<std::string, std::string>& variables) {
    std::vector<std::string> variableStrings{variables.size()};
    size_t i = 0;
    for (auto &element: variables) {
        variableStrings[i++] = element.first + "=" + element.second;
    }

    return convertToCArgs(variableStrings);
}

class MyShell {
    using variables_t = std::unordered_map<std::string, std::string>;

    variables_t variables;
    variables_t envVariables;
    std::string workingDir;
    int errorno = 0;

public:
    MyShell(std::string path="") {
        workingDir = boost::filesystem::current_path().string() + "/";

        for (size_t i = 0; environ[i] != nullptr; ++i) {
            assignVariable(environ[i], envVariables, false);
        }
        
        std::string binDir = workingDir;
        if (!path.empty()) {
            boost::filesystem::path tryBinPath = boost::filesystem::path(path).parent_path().string();
            if (boost::filesystem::is_directory(tryBinPath)) binDir = tryBinPath.lexically_normal().string();
            tryBinPath = boost::filesystem::path(workingDir + "/" + tryBinPath.string());
            if (boost::filesystem::is_directory(tryBinPath)) binDir = tryBinPath.lexically_normal().string();
        }
        envVariables["PATH"] = envVariables["PATH"] + ":" + binDir;
    };

    void run() {
        char *s;

        std::string printString = workingDir + " > ";
        while ((s = readline(printString.c_str())) != nullptr) {
            add_history(s);

            try {
                executeSingleCommand(s);
            } catch(std::exception &e) {
                std::cout << e.what() << std::endl;
            }

            free(s);
            printString = workingDir + " > ";
        }
    }

    std::vector<std::string> splitCommandIntoParts(std::string line) {
        line = line + ' ';
        std::vector<std::string> lineParts;

        // read the parts
        std::ostringstream part;
        bool partBegin = true;
        bool partEnd = false;
        char quotes = 0;
        char prevC = 0;

        for (size_t i = 0; i < line.size(); ++i) {
            char c = line[i];

            // perform checks for letters
            if (c == '\\' && i + 1 < line.size() && (line[i+1] == '\"' || line[i + 1] == '\'')) {
                part << line[++i];
            } else if (c == '\"' || c == '\'') {
                if (partBegin) {
                    quotes = c;
                } else if (quotes != c) {
                    part << line[i];
                } else {
                    // TODO throw exception if no space
                    partEnd = true;
                }
            } else if (c == ' ' && !quotes) {
                partEnd = true;
            } else {
                part << line[i];
            }

            // save the part if one found
            if (partEnd) {
                std::string partString = part.str();
                part = std::ostringstream();

                if (!partString.empty()) {
                    // variable
                    if (quotes != '\'' && partString[0] == '$') {
                        std::string key = clearEscapeCharacters(partString.substr(1));
                        std::string value;
                        value = envVariables[key];
                        if (value.empty()) value = variables[key];
                        if (!value.empty()) lineParts.push_back(value);
                    }
                    // wildCard
                    else if (quotes != '\'' && isWildCard(partString)) {
                        std::vector<std::string> expandedPart = expandWildCard(partString);
                        lineParts.insert(lineParts.end(), expandedPart.begin(), expandedPart.end());
                    }
                    // normal
                    else {
                        if (quotes != '\'') partString = clearEscapeCharacters(partString);
                        lineParts.push_back(partString);
                    }
                }
                partEnd = false;
                partBegin = true;
                quotes = 0;
            } else {
                partBegin = false;
            }
        }

        return lineParts;
    };

    static void printHelp(const std::string command) {
        if (command == "mexport") std::cout << "mexport <var_name>[=VAL]\nStores the value as global variable";
        else if (command == "merrno") std::cout << "merrno [-h|--help] – display the end code of the last program or command";
        else if (command == "mpwd") std::cout << "mpwd [-h|--help] – display current path";
        else if (command == "mcd") std::cout << "mcd <path> [-h|--help]  - change path to <path>";
        else if (command == "mexit") std::cout << "mexit [exit code] [-h|--help]  – exit from myshell with [exit code]";
        else if (command == "mecho") std::cout << "mecho [text|$<var_name>] [text|$<var_name>]  [text|$<var_name>] - print arguments";

        std::cout << std::endl;
    };

    static bool isHelpPrint(std::vector<std::string> lineParts) {
        for (auto &part: lineParts) {
            if (part == "-h" || part == "--help") {
                printHelp(lineParts[0]);
                return true;
            }
        }
        return false;
    };

    void assignVariable(const std::string& command, variables_t& variables, bool replaceVariableValue=true) {
        size_t equalPos;
        if ((equalPos = command.find('=')) != std::string::npos) {
            if (equalPos == 0)
                throw std::invalid_argument("No variable name given");
            std::string key = command.substr(0, equalPos);
            std::string value = command.substr(equalPos + 1);

            if (replaceVariableValue && value[0] == '$') {
                std::string replaceKey = value.substr(1);
                value = envVariables[replaceKey];
                if (value.empty()) value = variables[replaceKey];
            }
            variables[key] = value;
        }
        else {
            variables[command] = "1";
        }
    }

    void execute(const std::string path, std::vector<std::string>& arguments) {
        pid_t pid = fork();
        if (pid == -1) {
            throw std::runtime_error("Could not start new process");
        }
        else if (pid > 0) {
            waitpid(pid, &errorno, 0);
            errorno = errorno >> 8;
        }
        else {
            char** argumentsString = convertToCArgs(arguments);
            char** variablesString = convertToCVariables(envVariables);
            execve(path.c_str(), (char **) argumentsString, (char **) variablesString);
        }
    }

    void executeSingleCommand(std::string line) {
        std::vector<std::string> lineParts = splitCommandIntoParts(std::move(line));
        if (lineParts.empty()) return;

        // BUILT-IN COMMANDS
        std::string command = lineParts[0];
        if (command == "mexport") {
            if (isHelpPrint(lineParts)) return;
            else if (lineParts.size() == 1 || lineParts.size() > 2)
                throw std::invalid_argument("Invalid number of arguments");
            assignVariable(lineParts[1], envVariables);
        }
        else if (command.find('=') != std::string::npos) {
            if (isHelpPrint(lineParts)) return;
            if (lineParts.size() > 1) throw std::invalid_argument("Invalid number of arguments");
            assignVariable(lineParts[0], variables);
        }
        else if (command == "merrno") {
            if (isHelpPrint(lineParts)) return;
            if (lineParts.size() > 1) throw std::invalid_argument("Invalid number of arguments");
            std::cout << errorno << std::endl;
        }
        else if (command == "mpwd") {
            if (isHelpPrint(lineParts)) return;
            if (lineParts.size() > 1) throw std::invalid_argument("Invalid number of arguments");
            std::cout << workingDir << std::endl;
        }
        else if (command == "mcd") {
            if (isHelpPrint(lineParts)) return;
            if (lineParts.size() > 2) throw std::invalid_argument("Invalid number of arguments");
            std::string dirPart = lineParts[1];
            std::string newWorkingDir;
            if (dirPart[0] == '/') newWorkingDir = dirPart;
            else newWorkingDir = workingDir + "/" + dirPart;

            boost::filesystem::path dir{newWorkingDir};
            if (!boost::filesystem::is_directory(dir)) {
                throw std::invalid_argument("Path not a directory");
            }
            workingDir = dir.lexically_normal().string();
            if (workingDir[workingDir.length() - 1] == '.')
                workingDir = workingDir.substr(0, workingDir.length() - 1);
            if (workingDir[workingDir.length() - 1] != '/')
                workingDir += '/';
        }
        else if (command == "mexit") {
            if (isHelpPrint(lineParts)) return;
            if (lineParts.size() > 2) throw std::invalid_argument("Invalid number of arguments");
            int exitCode = 0;
            if (lineParts.size() == 2) {
                try {
                    exitCode = std::stoi(lineParts[1]);
                } catch(...) {
                    throw std::invalid_argument("Invalid argument provided");
                }
            }

            _exit(exitCode);
        }
        else if (command == "mecho") {
            for (size_t i = 1; i < lineParts.size(); ++i) {
                std::cout << lineParts[i] << (i != lineParts.size() - 1 ? " " : "");
            }
            std::cout << std::endl;
        }

        // CURRENT DIRECTORY COMMANDS
        else if (command.substr(0, 2) == "./") {
            boost::filesystem::path path = boost::filesystem::path{workingDir + "/" + command};
            if (!boost::filesystem::is_regular_file(path))
                throw std::invalid_argument("File not found: " + command);
            std::string pathString = path.lexically_normal().string();
            execute(pathString, lineParts);
        }

        // PATH COMMANDS
        else {
            std::string fullCommand;

            size_t directoryI = 0;
            size_t prevDirectoryI = 0;
            std::string path = envVariables["PATH"];

            while (directoryI != path.length()) {
                directoryI = path.find(':', prevDirectoryI);
                if (directoryI == std::string::npos) directoryI = path.length();

                std::string executable = path.substr(prevDirectoryI, directoryI - prevDirectoryI) + "/" + command;

                if (!executable.empty() && boost::filesystem::is_regular_file(executable)) {
                    fullCommand = boost::filesystem::path{executable}.lexically_normal().string();
                }

                prevDirectoryI = directoryI + 1;
            }

            if (fullCommand.empty()) {
                throw std::invalid_argument("Command not found");
            }
            execute(fullCommand, lineParts);
        }
    }
};


int main(int argc, char** argv) {
    MyShell shell{argc > 0 ? argv[0] : ""};
    shell.run();

    return 0;
}