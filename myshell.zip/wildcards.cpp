#include "wildcards.h"

#include <sstream>
#include <stdexcept>
#include <boost/filesystem.hpp>

bool testWildCard(std::string& str, std::string& wildCard, size_t strI, size_t wildCardI) {
    for (;strI < str.size() && wildCardI < wildCard.size(); ++strI, ++wildCardI) {
        if (wildCard[wildCardI] == '\\') {
            if (wildCardI == wildCard.size() - 1)
                throw std::invalid_argument(R"(Invalid "\" in the end of parameter)");
            if (str[strI] != wildCard[++wildCardI]) return false;
        } else if (wildCard[wildCardI] == '[') {
            bool passed = false;
            ++wildCardI;

            for (;wildCard[wildCardI] != ']'; ++wildCardI) {
                if (wildCardI == wildCard.size() - 1)
                    throw std::invalid_argument(R"(Wild card starting with "[" has no closing bracket)");

                if (wildCard[wildCardI] == '\\') ++wildCardI;
                if (wildCard[wildCardI] == str[strI]) {
                    passed = true;
                    break;
                }
            }

            ++wildCardI; // skip ]
            if (!passed) return false;
        } else if (wildCard[wildCardI] == '*') {
            for (;strI <= str.size(); ++strI) {
                if (testWildCard(str, wildCard, strI, wildCardI + 1)) return true;
            }

            return false;
        } else if (wildCard[wildCardI] != '?') {
            if (str[strI] != wildCard[wildCardI]) return false;
        }
    }

    return strI == str.size() && wildCardI == wildCard.size();
}

bool testWildCard(std::string str, std::string wildCard) {
    return testWildCard(str, wildCard, 0, 0);
}

bool isWildCard(std::string part) {
    for (size_t i = 0; i < part.size(); ++i) {
        if (part[i] == '[' || part[i] == '*' || part[i] == '?') return true;
        if (part[i] == '\\') ++i;
    }
    return false;
}

std::string clearEscapeCharacters(std::string part) {
    std::ostringstream stream;
    for (size_t i = 0; i < part.size(); ++i) {
        if (part[i] == '\\' && i != part.size() - 1) ++i;
        stream << part[i];
    }
    return stream.str();
}

std::vector<std::string> expandWildCard (const std::string partToParse) {
    size_t filenameSlash = partToParse.find_last_of('/');
    std::string directory = filenameSlash == std::string::npos ? "." : partToParse.substr(0, filenameSlash);
    std::string wildCard = filenameSlash == std::string::npos ? partToParse : partToParse.substr(filenameSlash + 1);

    if (isWildCard(directory))
        throw std::runtime_error("Wild card is not supported for directories (" + directory + ")");

    std::vector<std::string> passedFiles;

    boost::filesystem::directory_iterator endIterator;
    for(boost::filesystem::directory_iterator iterator(directory); iterator != endIterator; ++iterator) {
        if (!boost::filesystem::is_regular_file(iterator->status())) continue;

        boost::filesystem::path file = *iterator;
        if (testWildCard(file.filename().string(), wildCard))
            passedFiles.push_back(file.lexically_normal().string());
    }

    if (passedFiles.empty()) {
        throw std::runtime_error("Wild card " + partToParse + " could not be extended.");
    }
    return passedFiles;
}
