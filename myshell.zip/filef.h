#ifndef MYCAT_FILEF_H
#define MYCAT_FILEF_H

// Only prints for %s and %d
// Returns 1 if error
int filef(int file_number, char* format, ...);

#endif //MYCAT_FILEF_H
